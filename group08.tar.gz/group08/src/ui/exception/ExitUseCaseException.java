package ui.exception;

public class ExitUseCaseException extends Exception {

	private static final long serialVersionUID = -5302748863619684144L;

	public ExitUseCaseException(String message) {
		super(message);
	}
}
